package com.example.mobileproject;

public class KwangApplicationDetailsItem {

    private String title;
    private String date;
    private String positision;
    private String type;
    private String payment;
    private String state;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPositision() {
        return positision;
    }

    public void setPositision(String positision) {
        this.positision = positision;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

}
