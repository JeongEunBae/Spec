package com.example.mobileproject;

public @interface Nullable {
}
